# Review và bộ sửa container verification — 14/10/2026

## Verdict

**Bản workflow trong báo cáo: chưa sẵn sàng chạy. Bộ sửa đi kèm: đã kiểm tra source, cú pháp và logic cục bộ; READY TO COMMIT FOR ACTIONS VALIDATION. Docker/container runtime vẫn NOT VERIFIED.**

App baseline: `8e4821e6d5bd59fa580a1e8f21d024e4e792f1fa`.
Processor baseline: `078dae21f9e23975676179fa189f5c01b605f49a`.
Đã kiểm tra remote main của app vẫn tại SHA baseline trong lượt này. Các artifact báo cáo chưa có trên main.

## Những điểm đã sửa

1. **Checkout workflow không thể dùng như bản báo cáo.** Backend job checkout app tại SHA cũ; SHA đó chưa có verification files. Bộ sửa checkout bộ kiểm chứng ở `harness` tại `github.sha` của lần chạy, app baseline ở `app-source`, processor baseline ở `processor-source`. Dockerfile/scripts lấy từ harness, source build lấy từ checkout ghim.
2. **Backend dùng port3000.** `server.ts:50` là `const PORT = 3000`; listener sử dụng biến đó. `ENV PORT=8080` không thay đổi listener. Bộ Dockerfile này EXPOSE3000. Deployment sau này phải cấu hình container port3000 hoặc mở một patch riêng để hỗ trợ PORT động; không được giả định image lắng nghe8080.
3. **Firebase config đầy đủ.** Synthetic JSON có project/app/auth/database/bucket fields rõ ràng. Workflow đặt file synthetic vào build context dưới tên mới; Dockerfile thay canonical JSON chỉ trong build layer, trước Vite/esbuild. Không thay JSON source để commit.
4. **Dependency check lấy từ bundle thực tế.** Không hardcode cors thành direct dependency. Script duyệt external require trong dist/server.cjs và resolve bằng runtime node_modules. Vite được require ở top-level dù khai báo trực tiếp trong devDependencies; ở lockfile này nó còn được giữ qua production peer graph. Kiểm tra production-only installation thực tế đã resolve được các import, không kết luận mất Vite chỉ từ nhãn devDependencies.
5. **Processor scripts đầy đủ.** Inspect đọc paragraphId/directAlignment; desiredAlignment khác trạng thái nguồn; apply truyền đủ bốn query params. Chạy inspect lại output, so digest, kiểm tra ZIP, giữ nguyên fixture, kiểm tra cleanup và busy429 bằng upload chưa hoàn tất trên cùng host.
6. **Giữ release gate đóng trong backend image.** Dockerfile env `DOCUMENT_FORMATTING_V1_RELEASE_APPROVED=false`. Backend artifact checks chạy với network=none, không bootstrap server/Firestore.
7. **Ghi evidence đúng phạm vi.** Workflow lưu build/test logs và local image ID vào artifacts. Chưa có registry push/revision thì không gọi đó là image digest đã deploy. Không có GCP secret/credential trong workflow.

## Kiểm chứng đã thực hiện trên bộ file sửa

- `bash -n`: hai shell scripts PASS.
- Embedded Python AST và Node syntax: PASS.
- YAML parse/structure: PASS; hai jobs; harness dùng github.sha, source checkout dùng đúng SHA ghim.
- Build app với đúng synthetic JSON của bộ sửa: PASS.
- Cài `npm ci --omit=dev --ignore-scripts --no-audit --no-fund` trong thư mục riêng: 668 packages; kiểm tra artifact bằng logic script backend PASS, 6 files scanned và 19 imports resolved (bao gồm Node builtins).
- Logic Python của script processor chạy với .NET host thật: auth, malformed422, inspect/apply/reinspect, digest, ZIP, source preservation, same-host429 và disconnect cleanup PASS. Chỉ lệnh Docker filesystem-inspection được thay bằng shim đọc temp root của host local. Đây là kiểm chứng **logic harness trên host local**, không phải Docker runtime PASS.
- Docker CLI/daemon vẫn không có ở môi trường Codex. Các dòng docker build/run chỉ được kiểm tra tĩnh; chờ Actions.

## Hiệu chỉnh báo cáo nghiệp vụ

Response app inspect là `{success,result,inspection}`; paragraph ở `inspection.paragraphs[]` với `paragraphId/directAlignment`, không phải `id/currentAlignment`. Giới hạn rõ **20MiB =20,971,520 bytes**. IAM run.invoker cấp trên **Cloud Run service** cho backend service-account principal; không mô tả là cấp quyền “gọi processor SA”.

Phần source contracts khác dùng báo cáo tự kiểm chứng trước đó. Việc đọc logs/CI không chứng minh live IAM, quota, image revision hoặc real Firebase staging. Production NO-GO.

## Cách áp dụng

ZIP có sáu file repository dưới `payload/`. Chỉ copy nội dung payload vào root Agent-Workspace:

- `.github/workflows/verify-containers-manual.yml`
- `verification/container-verification/processor/Dockerfile`
- `verification/container-verification/processor/test-processor-container.sh`
- `verification/container-verification/backend/Dockerfile`
- `verification/container-verification/backend/firebase-applet-config.synthetic.json`
- `verification/container-verification/backend/test-backend-container.sh`

`PATCH_MANIFEST.sha256` và báo cáo review là tài liệu bàn giao ngoài payload, không copy/commit vào repository.

Sau khi owner commit workflow trên default branch, vào Actions → **Manual Container Verification (Processor & Backend)** → Run workflow. Gửi link run để Codex kiểm tra jobs, logs và artifacts. Không provision/deploy trong bước này.
